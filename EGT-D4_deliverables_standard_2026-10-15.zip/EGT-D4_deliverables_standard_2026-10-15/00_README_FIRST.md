# EGT-D4 · 标准版交付物包（2026-10-15）

> **范围**：本包 = 档 4「标准版」（D0 + D1 + D2-S1/S2/S3 + D4）的全部交付物与结果说明。
> **不含 D3**（复折叠复核）：D3 已由本地 Boltz-2 跑完 WT + top5，但 hercynine 对照尚未补跑，
> 完整版交付包待 D3 收尾后另行提供。D3 中间结论已在 `out/D4_results_notes.md` 中如实标注。
> ⛔ 本包全部产出为**计算级假设**（🖥/⚠️）；Δscore 是**设计偏置量，不是亲和力差**。

## 三个可上页数字

1. **设计臂 N = 10 条**（79 条去重口袋指纹中综合排序前 10；采样 300 条 = 3 温度 × 100）
2. **top 10 Δscore 区间 +0.279 ~ +0.415**（WT = +0.054，全场最低）
3. **WT 分位：score_EGT 2.7% ｜ Δscore 0.0%**（300 条变体中）

## 包内容（`out/`）

| 文件 | 内容 | 对应 PPT/湿实验用途 |
|---|---|---|
| `D0_site_table.csv` | 20 口袋位点三层分类 + 跨束界面标注 | 3.4 页位点表 |
| `mfsT1_EGT.pdb` / `ligand_EGT.sdf` / `ligand_hercynine.sdf` | 设计骨架 + 修好键级的配体（EGT 含 C=S） | 结构展示图原料 |
| `D1_inputs/omit_AA_per_residue.json` | 13 个设计位点的允许氨基酸约束 | 方法学说明 |
| `D1_EGT_T{0.1,0.2,0.3}/seqs/mfsT1_EGT.fa` | 300 条采样序列（头部含 ligand_confidence） | 方法学说明 |
| `D2_S1_sequence_scores.csv` | S1 内在打分（逐变体） | — |
| `D2_S2_geometry_check.csv` | 301 条三段约束判定（⚠️ 本轮全过、无区分度，角色是一致性检查） | — |
| `D2_S3_selectivity_bias.csv` | ⭐ Δscore 反向筛选（301 条） | 3.5 页"计算版选择性检验" |
| `D2_S3_align_residuals.csv` + `backbone_EGT_with_hercynine_pose.pdb` | hercynine 位姿叠合（口袋 Cα RMSD 0.69 Å） | 方法学质控 |
| `D4_variant_shortlist.csv` | ⭐ 10 条短名单 + WT 行（含 WT 分位） | 3.4 页"变体短名单"块 |
| `D4_expected_phenotype.csv` | 每变体预期表型 + 判别实验 | 湿实验设计臂 |
| `D4_results_notes.md` | ⭐ 结果说明（结论 / 证据等级 / 未做清单 / 复跑命令） | 总说明 |
| `D2_S3/`（list json + score 日志）、`D1_run.log` | 复跑与审计用 | — |

> 大体积中间产物（packed 全原子模型、S3 的 602 个打分 .pt 等）未纳入本包；
> 全部可再生（复跑命令见 `D4_results_notes.md` §6），代码与数据已同步至
> GitHub: ApaTitee/EGT-mfsT1_varient_design。

## 给展示侧的三条提醒

1. 叙事口径：本包支撑「诊断 → 设计 → 计算筛选 → 短名单 → 湿实验」的**设计 → 筛选**两段；
   "选择性"终点 = 计算版反向筛选已做一轮（Δscore），**不是亲和力结论**。
2. WT 分位（2.7% / 0.0%）的表述建议：「在模型的序列偏好口径下，天然口袋离最优有明显距离」，
   不可表述为"天然口袋转运效率低"。
3. D3（Boltz-2 复折叠）的初步发现——**"读硫"第三段为预测器依赖**——会影响 3.4/3.5 页对
   T227 段的措辞，建议等完整版包到手后再定稿这两页。
